import turtle

def draw_circle(turtle, color, size, x, y):
    turtle.penup()
    turtle.color(color)
    turtle.fillcolor(color)
    turtle.goto(x,y)
    turtle.begin_fill()
    turtle.circle(size)
    turtle.end_fill()
    turtle.pendown()

tommy = turtle.Turtle()
tommy.shape("turtle")
tommy.speed(500)

draw_circle(tommy, "red", 50, 80, 25)
draw_circle(tommy, "white", 45, 80, 29)
draw_circle(tommy, "green", 50, 25, -25)
draw_circle(tommy, "white", 45, 25, -21)
draw_circle(tommy, "black", 50, -25, 25)
draw_circle(tommy, "white", 45, -25, 29)
draw_circle(tommy, "yellow", 50, -80, -25)
draw_circle(tommy, "white", 45, -80, -21)
draw_circle(tommy, "blue", 50, -130, 25)
draw_circle(tommy, "white", 45, -130, 29)

hideturtle()
